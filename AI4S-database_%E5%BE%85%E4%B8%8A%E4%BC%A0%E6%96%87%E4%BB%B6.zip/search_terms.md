# AI4S 检索词与政策来源说明

**版本：V3.1　文档日期：2026-10-14　数据库：Web of Science Core Collection**

## 1 修订范围与基线

本轮以提供的`检索式.txt`为操作基线。该文件与V3压缩包的`search_strategy_main.txt`逐字节一致，SHA-256为`2bcb8077e44bb32cf949ab3c2197b16c21f5902aa5fc0f6d603aac3cee4dc812`。本轮仅在第二逻辑块领域组新增数学22项、化工19项，并核实词项来源。基线的其他词项、字段、布尔结构与年份、语种、文献类型限制保持一致。

V2 Word说明书提供来源分级和论证形式，但其附录检索式不是当前TXT基线的同一版本。差异如下，不应将二者混用：

| 位置 | V2 Word附录 | 当前TXT基线 | 本轮处理 |
| --- | --- | --- | --- |
| 显式AI4S块 | TI/AB/AK的OR | TS | 当前基线已包含Keywords Plus；本轮沿用 |
| 第二块领域字段 | TI/AB/AK的OR | TS | 不等价；本轮不再切换字段 |
| 第二块科研任务 | 41项 | 33项 | 有8项已被删去；本轮不恢复 |
| 第二块领域词 | 38项 | 42项 | 词表已收窄和替换；本轮保留42项 |
| SciML块 | TI/AB/AK的OR | TS | 本轮沿用当前基线 |

V2原有41个摘要任务词中，当前基线已移除8项：`"hypothesis test*"`；`"mechanism elucidat*"`；`"climate predict*"`；`"multidisciplinary simulat*"`；`"scientific simulat*"`；`"experimental validation"`；`"experimental outcome*"`；`"system architecture design"`。本轮不恢复这些词，以便将变更明确限定为新增领域。

## 2 三个逻辑块与字段

```text
[显式AI4S in TS]
OR [(AI方法 in TI OR AK) AND (科研任务 in AB)
    AND ((原有领域 OR 数学 OR 化工) in TS)]
OR [(SciML in TS) AND (方程或物理约束 in AB)]
整体 AND PY=(2010-2026) AND LA=(English) AND DT=(Article)
```

TI为标题，AK为作者关键词，AB为摘要；TS覆盖标题、摘要、作者关键词和Keywords Plus。字段配置旨在提高相关性，但同篇共现不能证明AI与某项科研任务存在实际执行关系，仍须筛选。领域门槛仅作用于第二块。

V3拆分为主式、数学补充式和化工补充式的方案，在词表、字段、全局限制及数据库快照相同的条件下，取并集与将新增领域直接OR并入主式在布尔逻辑上等价。拆分可以测量各领域增量，不能阻止合并结果规模扩大。本版采用一条正式完整检索式，并保留集合对照的记录方法。

## 3 词项来源分级

| 级别 | 定义 | 使用规则 |
| --- | --- | --- |
| A | 官方来源直接点名的概念，允许标准中英翻译 | 注明来源是政策正文、部署信息还是学科资助范围，不声称英文词逐字出现在中文原文 |
| B | 将官方上位概念或研究活动操作化为英文检索表达 | 说明转换关系，如传递现象到transport phenomena |
| C | 代表性文献或领域惯用语补充 | 明确这是补词，不将其写成政策直接列出的词 |

AI方法词来自方法学和论文用语；政策主要用于支持科研领域与任务范围。官方部署信息、学科资助范围、政策正文和政策解读不能相互冒充。P5、P6的年份早于V2优先选择的2024—2026年政策，系本轮为补足数学依据而明确新增的回溯来源；政策来源年份不改变文献检索的2010—2026年范围。

## 4 政策与官方资助依据

全部来源访问日期为2026-10-14。P7、P9无独立发布日期，按访问日期记录。

| 编号 | 来源与链接 | 机构及时间 | 文件类型 | 用途 |
| --- | --- | --- | --- | --- |
| P1 | [国家重点研发计划颠覆性技术创新重点专项2025年度人工智能驱动的科学研究领域项目申报指引](https://service2.most.gov.cn/kjjh_tztg_all/20250515/5682.html) | 京津冀国家技术创新中心；国家科技管理信息系统公共服务平台公开；2025-05-13落款；2025-05-15发布 | 项目申报指引 | 原有四类方向及发现、验证、设计、仿真等任务的主要依据。 |
| P2 | [国务院关于深入实施“人工智能+”行动的意见](https://www.gov.cn/zhengce/zhengceku/202508/content_7037862.htm)；[官方转载](https://www.mee.gov.cn/zcwj/gwywj/202508/t20250827_1126207.shtml) | 国务院；国发〔2025〕11号；2025-08-21成文 | 国务院政策文件 | 支持AI驱动科学发现；生产工艺优化属于产业行动，需与科研用途区分。 |
| P3 | [Launching the Genesis Mission](https://www.whitehouse.gov/presidential-actions/2025/11/launching-the-genesis-mission/) | The White House；Executive Order 14363；2025-11-24 | 美国联邦行政令 | 原有先进制造、生物技术、关键材料、核能、量子信息及微电子方向的依据。 |
| P4 | [Energy Department Announces 26 Genesis Mission Science and Technology Challenges to Accelerate AI-Enabled American Innovation and Leadership](https://www.energy.gov/undersecretaryforscience/articles/energy-department-announces-26-genesis-mission-science-and) | U.S. Department of Energy；2026-02-12 | 官方挑战部署公告 | 对原有领域进行交叉校验；使用固定日期公告，不据此推定数学或化工被单独列为优先领域。 |
| P5 | [关于加强数学科学研究工作方案](https://www.cas.cn/zcjd/201909/t20190918_4715042.shtml) | 科技部、教育部、中科院、自然科学基金委；2019-07-12成文；国科办基〔2019〕61号 | 四部门数学研究政策 | 支持基础数学、应用数学、科学与工程计算、计算机数学等方向。其数学支撑AI的表述不能倒置为AI用于数学研究。 |
| P6 | [科技部启动“人工智能驱动的科学研究”专项部署工作](https://kw.beijing.gov.cn/xwdt/kcyx/xwdtcyfz/202303/t20230328_3817948.html) | 北京市科委、中关村管委会官网转载新华社部署报道；2023-03-28页面发布日期 | 官方部署信息，非独立政策正文 | 专项部署直接提到数学，提供将数学纳入AI4S范围的直接部署依据。 |
| P7 | [数学科学处资助范围与联系方式](https://www.nsfc.gov.cn/p1/2851/3082/3089/sxkxc.html) | 国家自然科学基金委员会；页面无独立发布日期；访问于2026-10-14 | 官方学科资助范围，非独立AI4S政策 | 提供代数几何、分析、微分方程与动力系统、统计与运筹、计算数学等词簇边界。 |
| P8 | [原材料工业数字化转型工作方案（2024—2026年）及附件1石化化工行业数字化转型实施指南](https://www.miit.gov.cn/jgsj/ycls/wjfb/art/2024/art_df31d4ff7a794bb3a29826e1bf33e3e1.html)；[官方转载](https://www.hunan.gov.cn/zqt/zcsd/202401/t20240126_32635403.html)；[完整附件PDF](https://www.hunan.gov.cn/zqt/zcsd/202401/32635403/files/5fb304e4c4434dc184ff6af1cd3fe9b6.pdf) | 工业和信息化部等九部门；2024-01-16成文；工信部联原〔2023〕270号 | 部门工作文件及行业指南 | 附件1专栏7涉及反应条件优化、催化剂结构生成及性能和反应动力学预测。仅提取与科研设计有关的内容。 |
| P9 | [化学科学五处资助范围与联系方式](https://www.nsfc.gov.cn/p1/2852/3164/3178/hxkxwc.html) | 国家自然科学基金委员会；页面无独立发布日期；访问于2026-10-14 | 官方学科资助范围，非独立政策文件 | 界定化学工程与工业化学B08，并明确AI驱动的化工研究方向；支持传递、反应、过程强化和生物制造等词簇。 |
| P10 | [石化化工行业数字化转型实施指南解读材料](https://www.miit.gov.cn/zwgk/zcjd/art/2024/art_46958ce3847a4c208a21f744c9b20331.html)；[官方转载](https://policy.mofcom.gov.cn/claw/policyInfo.shtml?id=6055) | 工信部原文；商务部全球法规网转载；2024年；商务部转载页日期2024-02-27 | 官方政策解读，非指南正文 | “三传一反”出现在该解读中；不能将其误记为已核实的指南正文措辞。 |

### 4.1 数学的依据链

P6的专项部署信息将数学纳入基础学科问题范围，直接支持数学作为AI4S研究领域。P5提供数学研究的政策基础，P7用于细分学科词簇。P5中数学支撑人工智能的内容不能反向证明人工智能用于数学研究；这一方向性证据由P6及L1、L2的实际研究补足。

### 4.2 化工的依据链

P9将化学工程与工业化学界定为物质转化中流动、传递、反应及其关系的研究，并明确人工智能驱动的化工研究方向。P8附件1的“人工智能应用场景发掘工程”见PDF第21—22页，可支持反应条件优化、催化剂结构与性能研究的科研语境。领域词据此覆盖过程、反应、分离与跨尺度工程。

P8同时包括设备维护、安全预警等产业场景，这些内容不自动满足本研究的AI4S纳入标准。“三传一反”措辞核实于P10解读材料，不将其误记为P8指南正文的直接摘录。

## 5 原有领域词

以下42项原样保留，仅为阅读分组，各组在实际领域块中均用OR连接。原有化学与材料主要覆盖分子、反应和材料对象；新增化工强化过程、装置、单元操作和跨尺度研究。二者可以重叠，不能作为互斥分类。

| 词簇 | 词项数 | 检索词 |
| --- | --- | --- |
| 原有化学与材料 | 10 | `"materials science"`；`"materials informatics"`；`"material* design"`；`"material* discover*"`；`"critical material*"`；`"chemical science*"`；`"chemical synthesis"`；`catalys*`；`"reaction predict*"`；`retrosynthes*` |
| 原有物理与量子核科学 | 9 | `"quantum physics"`；`"quantum information science"`；`"nuclear physic*"`；`"particle physics"`；`"high energy physics"`；`"fusion energy"`；`"nuclear fusion"`；`"nuclear fission"`；`"plasma physics"` |
| 原有天文与空间 | 3 | `astrophysic*`；`astronom*`；`"space science*"` |
| 原有地球与气候 | 3 | `"earth science*"`；`geoscience*`；`"climate science*"` |
| 原有生命与健康 | 9 | `biotechnology`；`genomic*`；`proteomic*`；`"protein design"`；`"protein structure"`；`"drug discover*"`；`"drug design"`；`"biomedical science*"`；`"medical science*"` |
| 原有能源系统 | 3 | `"nuclear energy"`；`"energy system*"`；`"power grid"` |
| 原有工程与先进制造 | 5 | `"advanced manufacturing"`；`semiconductor*`；`microelectronic*`；`"engineering design"`；`"complex engineering system*"` |

## 6 数学新增词

共22项。学科名与对象词共同补足仅检索mathematics造成的漏检；这些词命中也可能代表其他学科使用了数学方法，需结合研究对象核验。

| 序号 | 检索词 | 级别 | 依据 | 理由 |
| --- | --- | --- | --- | --- |
| 1 | `mathematics` | A | P6 | AI4S专项部署直接提到数学 |
| 2 | `"mathematical science*"` | B | P5 | 数学科学的英文规范化表述 |
| 3 | `"applied mathematics"` | A | P5 | 文件直接支持应用数学研究 |
| 4 | `"computational mathematics"` | A | P7 | 资助范围直接列出计算数学 |
| 5 | `"numerical analysis"` | B | P7 | 计算方法构造及理论分析的英文操作化 |
| 6 | `"numerical linear algebra"` | B | P7 | 对数值代数的学术化表达 |
| 7 | `"differential equation*"` | A | P7 | 微分方程学科词，包含常微分和偏微分等短语 |
| 8 | `"inverse problem*"` | B | P7 | 反问题建模与计算的英文操作化 |
| 9 | `"dynamical system*"` | A | P7 | 动力系统学科名称 |
| 10 | `"nonlinear dynamics"` | C | P7上位范围 | 动力系统方向的领域惯用语 |
| 11 | `"graph theory"` | A | P7 | 资助范围直接列出图论 |
| 12 | `combinatorics` | A | P7 | 资助范围直接列出组合数学 |
| 13 | `"number theory"` | A | P7 | 数论学科词 |
| 14 | `"algebraic geometry"` | A | P7 | 代数几何学科词，补齐V3几何方向 |
| 15 | `"algebraic topology"` | A | P7 | 代数拓扑学科词 |
| 16 | `"differential geometry"` | A | P7 | 微分几何学科词 |
| 17 | `"functional analysis"` | A | P7 | 泛函分析学科词 |
| 18 | `"operator theory"` | A | P7 | 算子理论学科词 |
| 19 | `"probability theory"` | B | P7 | 概率理论方向的归并表达 |
| 20 | `"optimization theory"` | A | P7 | 资助范围直接列出优化理论 |
| 21 | `"symbolic computation"` | C | P5上位范围 | 计算机数学方向的领域惯用语 |
| 22 | `"computer algebra"` | C | P5上位范围 | 计算机数学方向的领域惯用语 |

## 7 化工新增词

共19项。优先使用学科、过程和装置对象词；保留跨学科的transport phenomena、multiphase flow等表达，但不将其视为化工专属标签。

| 序号 | 检索词 | 级别 | 依据 | 理由 |
| --- | --- | --- | --- | --- |
| 1 | `"chemical engineering"` | A | P9 | 化学工程学科名称 |
| 2 | `"process engineering"` | A | P9 | 资助范围直接列出过程工程 |
| 3 | `"process systems engineering"` | C | L3 | 规范的PSE术语，替换过宽的process system* |
| 4 | `"chemical process*"` | B | P8、P9 | 以chemical限定物质转化过程 |
| 5 | `"reaction engineering"` | A | P9 | 资助范围直接列出反应工程 |
| 6 | `"chemical reactor*"` | C | L3上位讨论 | 反应工程对象词，以chemical限定反应器 |
| 7 | `"reactor design"` | C | 反应工程惯用语 | 面向反应器结构与设计的对象词 |
| 8 | `"process intensification"` | A | P9 | 过程强化的标准英文名称 |
| 9 | `"separation process*"` | C | 化工单元操作惯用语 | 覆盖化工分离过程 |
| 10 | `distillation` | C | L3 | 文献明确讨论蒸馏过程的混合建模 |
| 11 | `"membrane separation"` | C | 化工单元操作惯用语 | 以明确短语覆盖膜分离 |
| 12 | `"polymer processing"` | C | 高分子加工惯用语 | 聚焦高分子加工过程 |
| 13 | `petrochemical*` | A | P8 | 石化行业对象词 |
| 14 | `"flow chemistry"` | C | L4 | 机器人流动合成的学术用语 |
| 15 | `"transport phenomena"` | B | P9、P10 | 对传递现象及三传机理的英文操作化 |
| 16 | `"multiphase flow"` | C | P9上位范围 | 流动与跨尺度过程研究的惯用语 |
| 17 | `bioprocess*` | B | P9 | 生物制造过程方向的英文操作化 |
| 18 | `"biochemical engineering"` | B | P9 | 生物制造与化学工程交叉方向 |
| 19 | `"electrochemical engineering"` | B | P9 | 光电转化及储能工程方向的英文操作化 |

## 8 相对V3试改词表的调整

V3试改为数学37项、化工28项；其备用合并式领域块共107项。本版为数学22项、化工19项，领域块共83项。数学新增algebraic geometry；化工将process system*规范化为process systems engineering，并新增chemical process*与biochemical engineering。删减依据是词义范围及与研究定义的匹配，尚无实测精确率证明删减效果。

| 词簇 | 涉及词项 | 调整理由 |
| --- | --- | --- |
| 数学数值方法泛词 | numerical method*；scientific computing；finite element method*；spectral method*；uncertainty quantification | 容易把跨学科方法使用误当成数学研究领域；从本轮主词表移出，不能据此断言这些方向不属于AI4S |
| 数学方程子类 | partial differential equation*；ordinary differential equation*；stochastic differential equation* | 由differential equation*作为领域词归并；第三块的PDE相关词原样保留 |
| 数学跨域术语 | stochastic process*；statistical inference；convex optimization；combinatorial optimization；operations research；information theory | 可能扩展到金融、管理、调度及通信应用；待净新增抽样后再评估 |
| 数学任务名称 | automated theorem proving；mathematical discovery | 应在任务维度讨论；放在TS领域侧无法补上AB任务缺口 |
| 化工泛化过程词 | process design；process optimi*；process control；process simulation；process model* | 缺少chemical等对象限定，易与业务流程或一般控制应用重叠 |
| 化工宽泛对象和方法 | continuous flow；scale-up；computational fluid dynamics；process safety | 不具有化工专属性，或偏日常运行维护；本轮移出 |
| 化工归并与规范化 | polymerization；industrial chemistry；process system* | 前两项本轮移出；process system*替换为process systems engineering；新增chemical process*与biochemical engineering |

## 9 已知覆盖边界及验证方法

1. **领域词新增不等于任务覆盖完整。** 现有AB任务组缺少theorem proving、conjecture generation等数学任务；摘要只写这些任务的论文仍可能漏检。化工摘要仅写process optimization、reaction optimization、reactor design等，也未必匹配原有任务组。本轮不扩展AB组。若研究目标需要完整覆盖这些方向，应将“领域扩展”和“任务词扩展”分别记录和实测。
2. **来源支持与命中效果分开。** 政策和资助范围说明为何选定词簇，不证明词表穷尽，也不证明某篇论文已纳入。L1、L2、L4可作为覆盖核验的参考论文；先确认其WoS收录、题录字段和文献类型，再检查是否命中。L3用于术语依据，不能默认满足Article限制。
3. **统计范围分开。** 检索命中总量是候选文献量，人工筛选后总量是分析样本量。新增词项数41不是净新增文献数。2026年是部分年度，学科分类允许一篇多类，不相加为总样本量。
4. **本轮验证。** 同日、同索引库运行基线及修订式，计算修订式NOT基线的净新增。可另以第二块原有方法、任务和各新增领域词构造数学与化工诊断集合；这些集合仅用于增量对照和抽样，不形成新的正式方案。
5. **筛选建议。** 建议对数学、化工净新增分别抽样核验，并公开抽样方式、样本量和排除原因。AI辅助教学、经营管理、例行监控，以及未承担目标科研任务的背景提及不纳入；工程设计和优化是否纳入应依据具体科研对象判断。

## 10 代表性文献与字段依据

| 编号 | 文献 | 用途 |
| --- | --- | --- |
| L1 | [Davies, A., et al. (2021). Advancing mathematics by guiding human intuition with AI. Nature, 600, 70–74.](https://doi.org/10.1038/s41586-021-04086-x) | 说明AI支持纯数学研究的实际路径，不把论文中所有数学术语自动加入检索式。 |
| L2 | [Romera-Paredes, B., et al. (2024). Mathematical discoveries from program search with large language models. Nature, 625, 468–475.](https://doi.org/10.1038/s41586-023-06924-6) | 用于检验数学发现的研究边界；论文在线发表于2023年，卷期年为2024年。 |
| L3 | [Schweidtmann, A. M., et al. (2021). Machine Learning in Chemical Engineering: A Perspective. Chemie Ingenieur Technik, 93(12), 2029–2039.](https://doi.org/10.1002/cite.202100083) | 核实PSE术语、反应器与蒸馏过程建模等用语；不将综述本身作为DT=Article一定能检出的哨兵论文。 |
| L4 | [Coley, C. W., et al. (2019). A robotic platform for flow synthesis of organic compounds informed by AI planning. Science, 365, eaax1566.](https://doi.org/10.1126/science.aax1566) | 补充flow chemistry与机器人流动合成的科研语境。 |

**F1**：[Clarivate官方Web of Science Starter API客户端字段说明](https://github.com/clarivate/wosstarter_python_client/blob/master/README.md)。其TS条目明确列出Title、Abstract、Author keywords及Keywords Plus。原帮助页已转向新帮助中心，故保留当前可核实的官方说明链接。

## 11 方法部分可用表述

本研究采用政策及官方学科资助范围界定词簇、代表性文献和领域术语补充的方式构建AI4S检索词。检索式包括显式AI4S表述、AI方法与科研任务及科学领域的交叉约束、Scientific Machine Learning与方程或物理约束三条路径。本轮在第二路径的领域词组中补入数学与化学工程，数学依据数学研究政策、2023年AI4S专项部署信息及数学学科资助范围，化工依据石化化工数字化转型指南中的科研设计场景及化学工程学科资助范围。新增领域词统一以OR连接，其他字段、任务词和全局限制沿用当前基线。所有词项区分官方概念、语义操作化和文献或惯用语补充；检索命中作为候选记录，另经人工核验确定分析样本。

## 12 完整可复制检索式

复制下方代码块内部全部内容至WoS Core Collection高级检索。代码块不含分组标注或说明文字。此式已完成本地结构校验，仍需在实际WoS界面确认执行及结果量。

```text
(
TS=(
"AI for science"
OR "artificial intelligence for science"
OR "AI4S"
OR "AI4Science"
OR "AI for scientific discover*"
OR "artificial intelligence for scientific discover*"
OR "AI-driven scientific discover*"
OR "AI-enabled scientific discover*"
OR "AI-accelerated scientific discover*"
OR "machine learning for science"
OR "self-driving laborator*"
OR "autonomous laborator*"
OR "robotic laborator*"
OR "closed-loop laborator*"
)

OR

(
(
TI=(
"artificial intelligence"
OR "machine learning"
OR "deep learning"
OR "neural network*"
OR "graph neural network*"
OR GNN*
OR "foundation model*"
OR "generative model*"
OR "large language model*"
OR "Bayesian optimization"
OR "active learning"
OR "reinforcement learning"
OR "diffusion model*"
)

OR

AK=(
"artificial intelligence"
OR "machine learning"
OR "deep learning"
OR "neural network*"
OR "graph neural network*"
OR GNN*
OR "foundation model*"
OR "generative model*"
OR "large language model*"
OR "Bayesian optimization"
OR "active learning"
OR "reinforcement learning"
OR "diffusion model*"
)
)

AND

AB=(
"scientific discover*"
OR "hypothesis generat*"
OR "causal infer*"
OR "equation discover*"
OR "physical law discover*"
OR "governing equation*"
OR "mechanism discover*"
OR "mechanism infer*"
OR "symbolic regression"
OR "structure-function*"
OR "material* discover*"
OR "drug discover*"
OR "virtual screen*"
OR "high-throughput screen*"
OR "inverse design"
OR "de novo design"
OR "molecular design"
OR "protein design"
OR "catalyst design"
OR "molecule generat*"
OR "protein structure predict*"
OR "molecular propert* predict*"
OR "material* propert* predict*"
OR "reaction predict*"
OR retrosynthes*
OR "experiment* design"
OR "experiment* planning"
OR "autonomous experiment*"
OR "closed-loop experiment*"
OR "self-driving laborator*"
OR "robotic laborator*"
OR "design space explor*"
OR "design optim*"
)

AND

TS=(
"materials science"
OR "materials informatics"
OR "material* design"
OR "material* discover*"
OR "critical material*"

OR "chemical science*"
OR "chemical synthesis"
OR catalys*
OR "reaction predict*"
OR retrosynthes*

OR "quantum physics"
OR "quantum information science"
OR "nuclear physic*"
OR "particle physics"
OR "high energy physics"
OR "fusion energy"
OR "nuclear fusion"
OR "nuclear fission"
OR "plasma physics"

OR astrophysic*
OR astronom*
OR "space science*"

OR "earth science*"
OR geoscience*
OR "climate science*"

OR biotechnology
OR genomic*
OR proteomic*
OR "protein design"
OR "protein structure"
OR "drug discover*"
OR "drug design"
OR "biomedical science*"
OR "medical science*"

OR "nuclear energy"
OR "energy system*"
OR "power grid"

OR "advanced manufacturing"
OR semiconductor*
OR microelectronic*
OR "engineering design"
OR "complex engineering system*"

OR mathematics
OR "mathematical science*"
OR "applied mathematics"
OR "computational mathematics"
OR "numerical analysis"
OR "numerical linear algebra"
OR "differential equation*"
OR "inverse problem*"
OR "dynamical system*"
OR "nonlinear dynamics"
OR "graph theory"
OR combinatorics
OR "number theory"
OR "algebraic geometry"
OR "algebraic topology"
OR "differential geometry"
OR "functional analysis"
OR "operator theory"
OR "probability theory"
OR "optimization theory"
OR "symbolic computation"
OR "computer algebra"
OR "chemical engineering"
OR "process engineering"
OR "process systems engineering"
OR "chemical process*"
OR "reaction engineering"
OR "chemical reactor*"
OR "reactor design"
OR "process intensification"
OR "separation process*"
OR distillation
OR "membrane separation"
OR "polymer processing"
OR petrochemical*
OR "flow chemistry"
OR "transport phenomena"
OR "multiphase flow"
OR bioprocess*
OR "biochemical engineering"
OR "electrochemical engineering"
)
)

OR

(
TS=(
"scientific machine learning"
OR "physics-informed machine learning"
OR "physics informed machine learning"
OR "physics-informed neural network*"
OR "physics informed neural network*"
OR PINN*
OR "neural operator*"
)

AND

AB=(
"partial differential equation*"
OR PDE*
OR "governing equation*"
OR "physical law*"
OR "conservation law*"
OR "boundary condition*"
)
)
)

AND PY=(2010-2026)
AND LA=(English)
AND DT=(Article)
```
